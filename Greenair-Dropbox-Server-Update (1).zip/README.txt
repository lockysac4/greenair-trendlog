GREENAIR TRENDLOG - DROPBOX CONNECTION UPDATE

1. Extract this ZIP.
2. Upload server.js to the ROOT of your greenair-trendlog GitHub repository.
3. Replace the existing server.js.
4. Commit changes and wait for Render to redeploy.
5. Do not place server.js inside the public folder.
